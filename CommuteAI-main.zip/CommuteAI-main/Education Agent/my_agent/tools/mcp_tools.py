import os
from google.adk.tools.mcp_tool.mcp_toolset import McpToolset
from google.adk.tools.tool_context import ToolContext
from google.adk.tools.mcp_tool.mcp_session_manager import StdioConnectionParams
from mcp import StdioServerParameters


mcp_server_path = os.path.abspath(
    os.path.join(os.path.dirname(__file__), "../../mcp-national-rail/dist/index.js")
)

national_rail_tools = McpToolset(
    connection_params=StdioConnectionParams(
        server_params=StdioServerParameters(
            command="node",
            args=[mcp_server_path],
        ),
        timeout=30,
    )
)