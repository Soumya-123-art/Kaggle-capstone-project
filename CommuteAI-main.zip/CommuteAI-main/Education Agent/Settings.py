import google_adk
print(google_adk.__version__)
